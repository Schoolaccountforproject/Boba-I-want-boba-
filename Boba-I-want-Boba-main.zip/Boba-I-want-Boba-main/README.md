So basically this is a website talking about boba toppings. Open to new ideas and I am aiming to make this website the most comprehensive boba topping collection site on the internet! 
